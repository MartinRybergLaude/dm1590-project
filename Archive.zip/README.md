# DM1590-Project
Machine learning application (supervised &amp; unsupervised) on dataset
# ToDO: Write crap
